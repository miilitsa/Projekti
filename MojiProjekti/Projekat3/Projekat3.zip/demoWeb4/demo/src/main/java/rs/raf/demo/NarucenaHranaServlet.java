package rs.raf.demo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet(name = "orderedFoodServlet", value = "/ordered-food")
public class NarucenaHranaServlet extends HttpServlet {
    private String password;

    @Override
    public void init() throws ServletException {
        super.init();

        try {
            File file = new File(getServletContext().getRealPath("/WEB-INF/password.txt"));
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            if ((line = reader.readLine()) != null) {
                password = line.trim();
            } else {
                throw new ServletException("Lozinka nije pronadjena u fajlu password.txt");
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
            throw new ServletException("Nije moguce ucitati lozinku iz fajla");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();

        if (session.getAttribute("ordered") == null) {
            response.getWriter().println("Jos niste izvrsili porudzbinu");
            return;
        }

        String lozinka = request.getParameter("lozinka");

        if (lozinka == null || !lozinka.equals(password)) {
            response.getWriter().println("Pogresna lozinka");
            return;
        }


        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Odabrana jela</h1>");

        Map<String, Map<String, Integer>> brojiJela = (Map<String, Map<String, Integer>>) session.getAttribute("mealsCount");

        for (String day : OdaberiJeloServlet.DAYS) {
            Map<String, Integer> meal = brojiJela.get(day);

            if (meal != null && !meal.isEmpty()) {
                out.println("<table border='1'><tr><th>Jelo</th><th>Kolicina</th></tr>");
                for (Map.Entry<String, Integer> entry : meal.entrySet()) {
                    out.println("<tr><td>" + entry.getKey() + "</td><td>" + entry.getValue() + "</td></tr>");
                }
                out.println("</table>");
            }
        }
        out.println("<form method='POST' action='/ordered-food'>");
        out.println("<input type='submit' value='Restart - Izbrisi porudzbinu'/>");
        out.println("</form>");

        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();

        session.removeAttribute("ordered");
        session.removeAttribute("mealsCount");

        response.sendRedirect("/food-servlet");
    }
}
