package rs.raf.demo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

@WebServlet(name = "foodServlet", value = "/food-servlet")
public class OdaberiJeloServlet extends HttpServlet {
    public static final String[] DAYS = {"ponedeljak", "utorak", "sreda", "cetvrtak", "petak"};
    private Map<String, List<String>> jelaDnevno = new HashMap<>();
    private Map<String, Map<String, Integer>> brojiJela = new HashMap<>();  // Za brojanje jela po danima

    public void init() {
        for(String day: DAYS){
            try{
                List<String> jela = loadFromFile(day + ".txt");
                jelaDnevno.put(day, jela);
                brojiJela.put(day, new HashMap<>());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    private List<String> loadFromFile(String filename) throws IOException {
        List<String> jela = new ArrayList<>();
        File file = new File(getServletContext().getRealPath("/WEB-INF/" + filename));
        if (!file.exists()) {
            return jela;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                jela.add(line.trim());
            }
        }
        return jela;
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();

        if (session.getAttribute("ordered") != null) { //ako je ordered postavljen preusmeri korisnika
           response.getWriter().println("Porudzbina je napravljena i ne moze da se menja");
            return;
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Choose your food</h1>");
        out.println("<h2>Izaberite vasa jela</h2>");
        out.println("<form method='POST' action='/food-servlet'>");

        for (String day : DAYS) {
            out.println("<label>" + day.substring(0, 1).toUpperCase() + day.substring(1) + ":</label><br>");

            List<String> meals = jelaDnevno.get(day);
            out.println("<select name='" + day + "' id='" + day + "'>");
            for (String meal : meals) {
                out.println("<option value='" + meal + "'>" + meal + "</option>");
            }
            out.println("</select><br>");
        }

        out.println("<input type='submit' value='Potvrdi unos'/>");
        out.println("</form>");
        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();

        if (session.getAttribute("ordered") != null) {
            response.sendRedirect("/ordered-food");
            return;
        }

        for (String day : DAYS) {
            String odabranoJelo = request.getParameter(day);
            if (odabranoJelo != null) {
                Map<String, Integer> brojacDnevnoJela = brojiJela.get(day);
                brojacDnevnoJela.put(odabranoJelo, brojacDnevnoJela.getOrDefault(odabranoJelo, 0) + 1);
            }
        }

        session.setAttribute("mealsCount", brojiJela);
        session.setAttribute("ordered", true);

        String lozinka = request.getParameter("lozinka");
       response.sendRedirect("/ordered-food?lozinka=" + lozinka);
    }
}
