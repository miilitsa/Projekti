package pomocniServis;

import app.Quote;
import app.QuoteRequestHandler;
import com.google.gson.Gson;
import http.ServerThread;

import javax.sound.sampled.Port;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;

import static app.NewsletterController.citati;

public class QuoteOfTheDayServis {
    public static final int PORT = 8114;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Quote server is running on port " + PORT);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                new Thread(new QuoteRequestHandler(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

            }
}

