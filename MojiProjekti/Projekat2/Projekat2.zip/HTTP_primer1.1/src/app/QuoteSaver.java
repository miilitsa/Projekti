package app;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class QuoteSaver {
    private static final String FILE_NAME = "quotes.json";

    public static void saveQuotesToFile(List<Quote> quotes) {
        try (FileWriter writer = new FileWriter(FILE_NAME)) {
            Gson gson = new Gson();
            String jsonCitat = gson.toJson(quotes);
            writer.write(jsonCitat);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Quote> loadQuotesFromFile() {
        List<Quote> quotes = new ArrayList<>();
        File file = new File(FILE_NAME);

        if (file.exists()) {
            try (FileReader reader = new FileReader(FILE_NAME)) {
                Gson gson = new Gson();
                Type tipCitata = new TypeToken<List<Quote>>(){}.getType(); //tip List<Quote> potreban za deserijalizaciju
                quotes = gson.fromJson(reader, tipCitata);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Fajl ne postoji, vrati praznu listu citata");
        }

        return quotes;
    }
}
