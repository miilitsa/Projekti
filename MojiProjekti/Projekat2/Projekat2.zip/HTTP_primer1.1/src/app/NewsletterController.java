package app;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import http.Request;
import http.response.HtmlResponse;
import http.response.RedirectResponse;
import http.response.Response;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static app.QuoteSaver.saveQuotesToFile;


public class NewsletterController extends Controller {

    public static List<Quote> citati = null;
    static {
        citati = QuoteSaver.loadQuotesFromFile();
    }

//    http://localhost:8113/quotes
    public static synchronized void addQuote(Quote quote) {
        citati.add(quote);
        System.out.println("Dodato u listu citata: " + quote.getQuoteText() + " - " + quote.getAuthor());
        saveQuotesToFile(citati);
    }

    public NewsletterController(Request request) {
        super(request);
    }

    @Override
    public Response doGet() {
        StringBuilder htmlBody = new StringBuilder();

        htmlBody.append("<style>")
                .append("body {")
                .append("display: flex;")
                .append("justify-content: center;")
                .append("align-items: center;")
                .append("flex-direction: column;")
                .append("height: 100vh;")
                .append("}")
                .append("h3, p {")
                .append("text-align: center;")
                .append("margin: 10px 0;")
                .append("}")
                .append("form {")
                .append("text-align: center;")
                .append("}")
                .append("button {")
                .append("background-color: #007BFF;")
                .append("}")
                .append("</style>");

        htmlBody.append("<form method=\"POST\" action=\"/save-quote\">")
                .append("<label>Author: </label><br>")
                .append("<input name=\"author\" type=\"text\"><br><br>")
                .append("<label>Quote: </label><br>")
                .append("<textarea name=\"quoteText\"></textarea><br><br>")
                .append("<button type=\"submit\">Save quote</button>")
                .append("</form><br><br>");


        String citatDana = getDnevniQuote();

        htmlBody.append("<h3>Quote of the day: </h3>")
                .append("<p>").append(citatDana).append("</p><br><br>");

        htmlBody.append("<h3>Saved quotes:</h3>");
        for (Quote quote : citati) {
            htmlBody.append("<p>").append(quote.getQuoteText()).append(" - ").append(quote.getAuthor()).append("</p>");
        }

        String content = htmlBody.toString();

        return new HtmlResponse(content);
    }

    @Override
    public Response doPost() {
        String quoteText = request.getPostParameter("quoteText");
        String author = request.getPostParameter("author");

        if (quoteText != null && author != null) {
            System.out.println("Broj citata pre dodavanja: " + NewsletterController.citati.size());
            NewsletterController.addQuote(new Quote(quoteText,author));
            System.out.println("Broj citata posle dodavanja: " + NewsletterController.citati.size());
            System.out.println("Sacuvan citat: " + author + " - " + quoteText);
        }
        sendQuoteServeru(new Quote(quoteText, author));
        return new RedirectResponse("/quotes");

    }

    private void sendQuoteServeru(Quote quote) {
        try (Socket socket = new Socket("localhost", 8114);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            Gson gson = new Gson(); //serijalizacija u json
            String jsonCitat = gson.toJson(quote);
            System.out.println("json koji saljem: " + jsonCitat);

            out.println("POST /save-quote HTTP/1.1");
            out.println("Host: localhost:8114");
            out.println("Content-Type: application/json");
            out.println();
            out.println(jsonCitat);

            String response = in.readLine();
            System.out.println("Odgovor od pomocnog servera: " + response);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getDnevniQuote() {
        try (Socket socket = new Socket("localhost", 8114);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            out.println("GET /quotes"); //saljem get zahtev za citat dana
            out.println();

            StringBuilder response = new StringBuilder();
            String line;
            boolean isJsonTelo = false;
            // ovde citam dok ne dodjem do kraja linije
            while ((line = in.readLine()) != null) {
                if (line.trim().isEmpty()) { //Ako je prazna linija citaj telo onda
                    isJsonTelo = true;
                    continue;
                }
                if (isJsonTelo) {
                    response.append(line);
                }
            }

            String responseString = response.toString().trim();  // ovde samo json telo nema zaglavlje
            System.out.println("Odgovor sa servera trimovan " + responseString);

            // deseralizacija JSON-a
            Gson gson = new Gson();
            Quote quote = null;

            try {
                 quote = gson.fromJson(responseString, Quote.class);
                if (quote != null) {
                    return quote.getQuoteText() + " - " + quote.getAuthor();
                } else {
                    System.err.println("Nema dobrog citata od servera ");
                }
            } catch (JsonSyntaxException e) {
                System.err.println("Greska u deseralizaciji  " + e.getMessage());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "Nema citata";
    }
}