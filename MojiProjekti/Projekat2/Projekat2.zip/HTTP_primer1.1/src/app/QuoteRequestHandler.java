package app;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import http.Request;
import http.response.Response;

import java.io.*;
import java.net.Socket;
import java.util.List;
import java.util.Random;

import static app.NewsletterController.citati;
import static java.lang.System.out;

public class QuoteRequestHandler implements Runnable {
    private Socket socket;

    public QuoteRequestHandler(Socket socket) {
        this.socket = socket;
    }

    static {
        citati = QuoteSaver.loadQuotesFromFile();
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true)) {

            String requestLine = in.readLine();
            System.out.println("REQUEST LINE " + requestLine);

            if (requestLine != null && requestLine.startsWith("GET /quotes")) {
                System.out.println("Uslo u QuoteRequestHandler klasu");

                StringBuilder header = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null && !line.isEmpty()) {
                    header.append(line);
                    System.out.println("HEADER LINE: " + line);
                }
                List<Quote> citati = QuoteSaver.loadQuotesFromFile();

                if (!citati.isEmpty()) {
                    System.out.println("USLO - IMA CITATA");
                    Random random = new Random();
                    Quote randomQuote = citati.get(random.nextInt(citati.size()));
                    System.out.println("RANDOM QUOTE: " + randomQuote);


                    Gson gson = new Gson();
                    String response = gson.toJson(new Quote(randomQuote.getQuoteText(),randomQuote.getAuthor()));

                    out.println("HTTP/1.1 200 OK");
                    out.println("Content-Type: application/json");
                    out.println();
                    out.println(response);
                } else {
                    out.println("HTTP/1.1 404 Not Found");
                    out.println("Content-Type: application/json");
                    out.println();
                    out.println("{\"message\": \"Nema citata\"}");
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}

