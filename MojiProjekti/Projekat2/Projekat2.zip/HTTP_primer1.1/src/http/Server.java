package http;

import com.google.gson.Gson;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;

public class Server {

    public static final int TCP_PORT = 8113;

    public static void main(String[] args) {


        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                obrisiFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }));
        try {
            ServerSocket ss = new ServerSocket(TCP_PORT);
            while (true) {
                Socket sock = ss.accept();
                new Thread(new ServerThread(sock)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static void obrisiFile() throws IOException {
        File file = new File("quotes.json");

        if (file.exists()) {
            boolean deleted = file.delete();
            if (deleted) {
                System.out.println("Fajl je obrisan");
            } else {
                System.out.println("Nemoguce obrisati fajl");
            }
        } else {
            System.out.println("Fajl ne postoji");
        }
    }

}
