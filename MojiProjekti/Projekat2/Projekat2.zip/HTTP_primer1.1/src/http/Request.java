package http;

import http.HttpMethod;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

public class Request {

    private final HttpMethod httpMethod;
    private final String path;
    private Map<String,String> postParametri;

    public Request(HttpMethod httpMethod, String path) {
        this.httpMethod = httpMethod;
        this.path = path;
        this.postParametri = new HashMap<>();
    }

    public HttpMethod getHttpMethod() {
        return httpMethod;
    }

    public String getPath() {
        return path;
    }


    public void setPostParameters(String body) {
        System.out.println("POST body: " + body);

        String[] pairs = body.split("&");

        for (String pair : pairs) {
            String[] keyValue = pair.split("="); //razdvaja na kljuc i vrednost

            if (keyValue.length == 2) {//ako ih ima
                try {
                    String key = URLDecoder.decode(keyValue[0], "UTF-8");
                    String value = URLDecoder.decode(keyValue[1], "UTF-8");

                    System.out.println("KEY: " + key + " VALUE: " + value);

                   if (key != null && !key.trim().isEmpty() && value != null && !value.trim().isEmpty()) {
                        postParametri.put(key, value);
                    } else {
                        System.out.println("Prazan key i vrednost..");
                    }
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        }
    }

        public String getPostParameter (String key){
            return postParametri.get(key);
        }
}

