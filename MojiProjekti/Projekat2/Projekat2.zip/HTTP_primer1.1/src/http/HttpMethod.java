package http;

public enum HttpMethod {
    GET, POST
}
