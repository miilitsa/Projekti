package http.response;

public abstract class Response {
    public abstract String getResponseString();
}
