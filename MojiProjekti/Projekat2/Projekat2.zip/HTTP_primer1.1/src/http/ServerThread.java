package http;

import app.NewsletterController;
import app.Quote;
import app.RequestHandler;
import com.google.gson.Gson;
import http.response.Response;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.StringTokenizer;

public class ServerThread implements Runnable {

    private Socket client;
    private BufferedReader in;
    private PrintWriter out;

    public ServerThread(Socket sock) {
        this.client = sock;

        try {
            //inicijalizacija ulaznog toka
            in = new BufferedReader(
                    new InputStreamReader(
                            client.getInputStream()));

            //inicijalizacija izlaznog sistema
            out = new PrintWriter(
                    new BufferedWriter(
                            new OutputStreamWriter(
                                    client.getOutputStream())), true);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        try {
            // uzimamo samo prvu liniju zahteva, iz koje dobijamo HTTP method i putanju
            String requestLine = in.readLine();
            System.out.println(requestLine);

            String[] requestParts = requestLine.split(" ");

            String method = requestParts[0];  // GET ili POST
            String path = requestParts[1];    // npr /quotes
            System.out.println("METHOD: " + method + " PATH: " + path);

            String headerLine;
            while((headerLine = in.readLine())!=null && !headerLine.trim().isEmpty()){
                System.out.println(headerLine);
            }

            Request request = new Request(HttpMethod.valueOf(method),path);


            if (method.equals(HttpMethod.POST.toString())) {
                System.out.println("USAO U POST METOD");
                StringBuilder body = new StringBuilder();

                while (in.ready()) {
                    int c = in.read();  // cita jedan karakter, int jer in.read vraca int a ne char
                    body.append((char) c);
                }
                System.out.println("BODY OD POSTA" + body.toString());
                request.setPostParameters(body.toString());
                System.out.println("BODY POSLE REQUEST: " + body.toString());
            }
            System.out.println("IZASAO IZ POST METOD");
            RequestHandler requestHandler = new RequestHandler();
            Response response = requestHandler.handle(request);
            System.out.println("RESPONSE IZ SERVERTHREAD" + response);

            System.out.println("Response.getString" + response.getResponseString());
            out.println(response.getResponseString());


            in.close();
            out.close();
            client.close();


        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
